create view v_category as
select `c3`.`id`   AS `id`,
       `c1`.`id`   AS `c1_id`,
       `c1`.`name` AS `c1_name`,
       `c2`.`id`   AS `c2_id`,
       `c2`.`name` AS `c2_name`,
       `c3`.`id`   AS `c3_id`,
       `c3`.`name` AS `c3_name`
from ((`gmall_product`.`base_category1` `c1` join `gmall_product`.`base_category2` `c2` on ((`c1`.`id` = `c2`.`category1_id`)))
         join `gmall_product`.`base_category3` `c3` on ((`c2`.`id` = `c3`.`category2_id`)));

-- comment on column v_category.id not supported: 编号

-- comment on column v_category.c1_id not supported: 编号

-- comment on column v_category.c1_name not supported: 分类名称

-- comment on column v_category.c2_id not supported: 编号

-- comment on column v_category.c2_name not supported: 二级分类名称

-- comment on column v_category.c3_id not supported: 编号

-- comment on column v_category.c3_name not supported: 三级分类名称


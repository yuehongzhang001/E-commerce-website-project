create definer = root@`%` view v_v1 as
select `canal_tsdb`.`t_user`.`id` AS `id`, `canal_tsdb`.`t_user`.`name` AS `name`
from `canal_tsdb`.`t_user`;

